
 
 
 document.addEventListener("deviceready", init, false);
 
 
 function init() { 
 // contains application logic 
 

    $("#playSound1").click(function()  {
		alert('in playsound 1');
 	  // you can download licensed audio file from http://www.orangefreesounds.com/ .
	  	  
	 //In Android, it's necessary to specific the asolute path
        var str = location.pathname;
        var i = str.lastIndexOf('/');
        var path = str.substring(0,i+1);
	    src = path + "media/lark.mp3"; 
		var my_media = new Media(src , onMediaSuccess, onMediaError);
        my_media.play();
	 
	
    }); // playMusic

    $("#playSound2").click(function()  {
      	alert('in playsound 2');  
	 //In Android, it's necessary to specific the asolute path
        var str = location.pathname;
        var i = str.lastIndexOf('/');
        var path = str.substring(0,i+1);
	    src = path + "media/water.mp3"; 
	    var my_media = new Media(src , onMediaSuccess, onMediaError);
	    my_media.play();
	 
  }); // playMusic
  

 }   //  end function init



function onMediaSuccess() { 
// insert app logic

}

function onMediaError(e) { 
// insert app logic}
alert("We are sorry but we can't play the sound" + e.message);
}








