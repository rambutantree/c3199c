 
document.addEventListener("deviceready", init, false);
 

 
function init() { 


 	$("#readQR").click(function()  {
	
		 cordova.plugins.barcodeScanner.scan(
           function (result) {
				 $("#custInfo").html('<h4>Data read from QR Code </h4> <br>' + result.text);
      }, 
          function (error) {
          alert("Scanning failed: " + error);
          }
       );
		
	});  // end readBarCode click
	
	
   $("#takePhoto").click(function()  {
	// alert('take photo');
    navigator.camera.getPicture(onCameraSuccess, onCameraFail,  
	{ quality: 50,
      destinationType: Camera.DestinationType.DATA_URL,
 	  sourceType : Camera.PictureSourceType.CAMERA, 
	  cameraDirection : Camera.Direction.BACK,
	  correctOrientation: true
	   
    });

  }); // end takePhoto


   $("#cfmDelivery").click(function()  {
	alert('cfmDelivery');
    
  });


  
}   //  end function init


function  onCameraSuccess(imageData) {
	    var image = document.getElementById('custPic');
         image.src = "data:image/jpeg;base64," + imageData;

}

function onCameraFail(e) { 
alert('Failed because: ' + message);
}















